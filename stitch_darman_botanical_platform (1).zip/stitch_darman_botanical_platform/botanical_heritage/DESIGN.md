---
name: Botanical Heritage
colors:
  surface: '#fbf9f2'
  surface-dim: '#dbdad3'
  surface-bright: '#fbf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4ed'
  surface-container: '#efeee7'
  surface-container-high: '#e9e8e1'
  surface-container-highest: '#e3e3dc'
  on-surface: '#1b1c18'
  on-surface-variant: '#404942'
  inverse-surface: '#30312c'
  inverse-on-surface: '#f2f1ea'
  outline: '#717971'
  outline-variant: '#c0c9bf'
  surface-tint: '#326947'
  primary: '#054426'
  on-primary: '#ffffff'
  primary-container: '#245c3b'
  on-primary-container: '#98d2a9'
  inverse-primary: '#99d4aa'
  secondary: '#406651'
  on-secondary: '#ffffff'
  secondary-container: '#bfeace'
  on-secondary-container: '#456b55'
  tertiary: '#2d4025'
  on-tertiary: '#ffffff'
  tertiary-container: '#44573a'
  on-tertiary-container: '#b6cca7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b4f0c5'
  primary-fixed-dim: '#99d4aa'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#175131'
  secondary-fixed: '#c2ecd1'
  secondary-fixed-dim: '#a7d0b6'
  on-secondary-fixed: '#002112'
  on-secondary-fixed-variant: '#294e3a'
  tertiary-fixed: '#d3e9c3'
  tertiary-fixed-dim: '#b7cda8'
  on-tertiary-fixed: '#0f2008'
  on-tertiary-fixed-variant: '#394c30'
  background: '#fbf9f2'
  on-background: '#1b1c18'
  surface-variant: '#e3e3dc'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined botanical archive rooted in indigenous herbal wisdom, sustainable agro-commerce, and regional botanical ecology. The aesthetic pairs classical natural history documentation with contemporary, accessible digital commerce.

### Brand Personality & Emotional Impact
- **Reverent & Grounded:** Evokes deep familiarity with earth, flora, and traditional botanical scholarship.
- **Approachable & Trustworthy:** Engineered specifically for both field harvesters and urban consumers, prioritizing legibility, tactile clarity, and effortless navigation over technical jargon.
- **Lush & Editorial:** Balances tranquil whitespace with rich organic tones to convey purity, authenticity, and scientific rigor.

### Design Movement & Visual Language
The system adopts an **Organic Editorial Minimalism** approach. It utilizes expansive parchment surfaces, disciplined typestacks pairing authoritative serifs with high-clarity humanist grotesque typography, and softly radiused structural containers. Rather than relying on synthetic effects or skeuomorphism, it honors tactile print field guides with subtle organic dividers, natural borders, and balanced whitespace.

## Colors

The palette draws directly from the dry highlands, wild medicinal shrubs, and fertile oasis pockets of the terrain. The core canvas relies on a calming, low-glare parchment base rather than sterile white, reducing eye fatigue during extended field reading.

### Palette Architecture
- **Primary (`#245C3B` - Forest Green):** The principal brand and interactive token. Used for critical primary actions, prominent taxonomic categorizations, key status badges, and focal interactive elements.
- **Secondary (`#173D2A` - Deep Shrub Green):** Anchors brand authority. Applied to high-emphasis headers, navigation backdrops, active states, and grounding structural containers.
- **Tertiary (`#A8BE9A` - Sage Green):** Connective organic tint. Deployed for subtle state indicators, secondary chip fills, organic highlight strokes, and soft botanical accents.
- **Neutral Surface (`#F8F7F0` - Mountain Cream):** The primary environment canvas. Provides warmth, organic tactile depth, and a high-legibility bed for rich botanical illustration and typography.
- **Base White (`#FFFFFF`):** Reserved for elevated card containers, input field backgrounds, and modal viewports to create crisp optical separation from the cream backdrop.
- **Text Primary (`#222222` - Dark Charcoal):** Delivers WCAG AAA contrast compliance across both cream and white surfaces without the starkness of pure black.

## Typography

The typographic hierarchy pairs **Playfair Display** (an elegant, transitional serif suited for botanical nomenclature and scientific storytelling) with **Plus Jakarta Sans** (a clean, highly legible grotesque sans with open counters and welcoming geometry).

### Typographic Principles
- **Scientific vs. Functional:** Editorial plant species titles, herbal monograph headers, and narrative sections use Playfair Display. Practical UI data, marketplace prices, search filters, and instructional workflows use Plus Jakarta Sans.
- **Legibility for Non-Technical Users:** Body copy is calibrated at 15px/24px and 18px/28px to ensure comfortable readability under varied lighting and on low-density mobile displays.
- **Botanical Latin Nomenclature:** Botanical species names rendered in Playfair Display should adopt an italic font style (e.g., *Peganum harmala*) alongside regional vernacular names set in medium-weight Plus Jakarta Sans.

## Layout & Spacing

The layout philosophy implements a disciplined **12-column fluid grid** for desktop and tablet displays, collapsing to a single or 2-column flow on mobile screens. 

### Spacing Philosophy
- **Airy Rhythm:** The layout incorporates breathing room around plant profiles, high-resolution specimen photography, and marketplace listings to prevent cognitive overload.
- **Breakpoints:**
  - **Mobile (< 640px):** 4-column layout, `margin-sm` (1rem), `gutter-sm` (1rem). Touch targets are maintained at a minimum of 48px height.
  - **Tablet (640px - 1024px):** 8-column layout, `margin` (2rem), `gutter` (1.5rem). Allows side-by-side catalog browsing and persistent filtration trays.
  - **Desktop (> 1024px):** 12-column layout with a maximum container bounding width of `1280px` to maintain optimal eye tracking during reading.

## Elevation & Depth

This system intentionally departs from heavy drop shadows to preserve an organic, botanical aesthetic. Depth is communicated primarily through **tonal layering** and **delicate physical framing**.

### Layering Hierarchy
1. **Base Ground (Level 0):** Neutral cream canvas (`#F8F7F0`), setting a soft, warm environment.
2. **Surface Containers (Level 1):** Solid white card planes (`#FFFFFF`) featuring a hairline border (`1px solid rgba(36, 92, 59, 0.12)`). This provides structural separation without muddy shadows.
3. **Interactive & Hover Surfaces (Level 2):** When a card or interactive module is focused or hovered, it introduces an ambient botanical shadow: `0 8px 24px -4px rgba(23, 61, 42, 0.08)`, gently lifting the surface toward the user.
4. **Floating Overlays & Modals (Level 3):** Botanical detail drawers, shopping carts, and lightbox sheets utilize a deep grounding shadow: `0 16px 36px -8px rgba(23, 61, 42, 0.16)` with a warm backdrop dim (`rgba(23, 61, 42, 0.4)`).

## Shapes

The geometric form language embodies softness and organic cohesion without appearing playful or juvenile. 

### Radii Application
- **Base Level (`roundedness: 2` / 0.5rem - 8px):** Applied to form inputs, buttons, filter chips, and image thumbnails.
- **Card Containers (`rounded-lg` / 1rem - 16px):** Applied to specimen profile cards, marketplace product cards, and instructional sections.
- **Panels & Dialogs (`rounded-xl` / 1.5rem - 24px):** Applied to modal sheets, cart flyouts, and promotional botanical banners.
- **Full Radius (Pill):** Reserved exclusively for status indicators, micro-badges (e.g., "Harvested Wild", "Organic Certified"), and counter tags.

## Components

### Buttons
- **Primary Button:** Filled with Forest Green (`#245C3B`), text in White (`#FFFFFF`). Padding: `0.75rem 1.5rem`. Border radius: `0.5rem`. Smooth hover transition to Deep Green (`#173D2A`).
- **Secondary Button:** Outlined with a `1.5px` border in Forest Green (`#245C3B`), background transparent or White (`#FFFFFF`), text in Forest Green. Hover transitions to Sage Green tint (`rgba(168, 190, 154, 0.15)`).
- **Botanical Action (Tertiary):** Borderless text button with trailing leaf or directional icon, utilizing `label-lg` styling.

### Cards
- **Product & Plant Specimen Cards:** Built on a pure white background (`#FFFFFF`) framed with a subtle border (`1px solid rgba(36, 92, 59, 0.1)`). Aspect ratio for specimen imagery is fixed at `4:3` or `1:1`, resting flush on top of the card with `rounded-t-[calc(1rem-1px)]`. Generous internal content padding of `1.25rem`.

### Chips & Filter Tags
- **Selection Chips:** Used for filtering medicinal uses, regions, and preparation forms.
  - *Inactive:* Background `rgba(168, 190, 154, 0.2)`, text `#173D2A`, border `1px solid transparent`.
  - *Active:* Background `#245C3B`, text `#FFFFFF`, border `1px solid #173D2A`.
  - Padding: `0.375rem 0.875rem`, shape: `rounded-full`.

### Input Fields & Search Bars
- **Text Inputs:** White background (`#FFFFFF`), border `1.5px solid rgba(36, 92, 59, 0.2)`, text `#222222`, placeholder `#738071`. Height: `48px` to guarantee accessible mobile tapping. Focused state shifts border to Forest Green (`#245C3B`) with a soft glow ring (`0 0 0 3px rgba(168, 190, 154, 0.35)`).

### Checkboxes & Radio Buttons
- **Selection Controls:** `20px` width/height. Unchecked state features a `1.5px` stroke of `#A8BE9A` against a white base. Checked state transitions to a solid `#245C3B` fill featuring a crisp white botanical checkmark or concentric circle.

### Specialized Botanical Components
- **Specimen Monograph Block:** A split-layout card with an archival botanical illustration on one flank and structured metadata (Local Name, Botanical Name, Active Compounds, Traditional Usage) formatted in tabular rows using `body-sm` and `label-md`.
- **Origin Badge:** Pill badge using Sage Green background (`#A8BE9A` at 25% opacity) and Deep Green text (`#173D2A`), explicitly communicating geographic origin and harvesting cooperatives.